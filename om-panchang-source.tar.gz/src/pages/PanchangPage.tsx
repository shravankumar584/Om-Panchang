import { useState, useEffect, useCallback, useRef } from "react";
import { CITIES, City, DayPanchang, computeDayPanchang, getFestivalsForDate } from "@/lib/panchangData";
import ReferenceSection from "@/components/ReferenceSection";
import VedicClock from "@/components/VedicClock";
import PlanetaryPositions from "@/components/PlanetaryPositions";
import UpcomingFestivals from "@/components/UpcomingFestivals";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

interface RashiInfo {
  index: number;
  name: string;
  english: string;
  symbol: string;
  lord: string;
  element: string;
  quality: string;
  description: string;
  traits: string[];
}

const RASHI_DATA: RashiInfo[] = [
  { index: 1, name: "Mesha", english: "Aries", symbol: "♈", lord: "Mangal (Mars)", element: "Fire (Agni)", quality: "Movable (Chara)", description: "Mesha is the first rashi, symbolizing new beginnings, courage, and raw energy. Ruled by Mangal (Mars), it bestows a pioneering, fearless spirit. Those with a strong Mesha influence are natural leaders who act decisively and thrive on challenges. The ram charges forward without hesitation.", traits: ["Courageous and pioneering", "Impulsive and action-oriented", "Natural leader", "Competitive and energetic", "Can be impatient or aggressive"] },
  { index: 2, name: "Vrishabha", english: "Taurus", symbol: "♉", lord: "Shukra (Venus)", element: "Earth (Prithvi)", quality: "Fixed (Sthira)", description: "Vrishabha is ruled by Shukra (Venus), bestowing a love of beauty, comfort, and sensory pleasures. The bull is steady, patient, and immovable once rooted. Vrishabha natives excel in accumulating wealth and creating beautiful, stable environments. They are deeply loyal but can be stubborn.", traits: ["Patient and reliable", "Love of luxury and comfort", "Strong material instincts", "Stubborn but devoted", "Artistic and sensual"] },
  { index: 3, name: "Mithuna", english: "Gemini", symbol: "♊", lord: "Budha (Mercury)", element: "Air (Vayu)", quality: "Dual (Dwiswabhava)", description: "Mithuna, ruled by Budha (Mercury), represents duality, communication, and intellectual curiosity. The twins embody the ability to see multiple sides of every situation. Mithuna natives are witty, adaptable, and excellent communicators — but can be scattered or inconsistent.", traits: ["Quick-witted and communicative", "Curious and adaptable", "Sociable and charming", "Can be indecisive or superficial", "Excellent with language and writing"] },
  { index: 4, name: "Karka", english: "Cancer", symbol: "♋", lord: "Chandra (Moon)", element: "Water (Jala)", quality: "Movable (Chara)", description: "Karka is ruled by Chandra (Moon), making it the most emotionally sensitive and nurturing rashi. The crab carries its home on its back — symbolizing the deep attachment to home, family, and roots. Karka natives are intuitive, protective, and deeply empathetic.", traits: ["Deeply nurturing and protective", "Emotionally sensitive and intuitive", "Strong attachment to home and family", "Can be moody or clingy", "Excellent memory and imagination"] },
  { index: 5, name: "Simha", english: "Leo", symbol: "♌", lord: "Surya (Sun)", element: "Fire (Agni)", quality: "Fixed (Sthira)", description: "Simha is ruled by Surya (Sun), the king of the planets, bestowing natural authority, dignity, and a desire to shine. The lion is the king of the jungle — proud, generous, and commanding. Simha natives are natural performers and leaders who radiate warmth and confidence.", traits: ["Natural leader and performer", "Generous and magnanimous", "Proud and dignified", "Creative and dramatic", "Can be arrogant or attention-seeking"] },
  { index: 6, name: "Kanya", english: "Virgo", symbol: "♍", lord: "Budha (Mercury)", element: "Earth (Prithvi)", quality: "Dual (Dwiswabhava)", description: "Kanya, the maiden, is ruled by Budha (Mercury) and represents discernment, service, and attention to detail. Kanya natives have sharp analytical minds and a desire to be of practical service. They excel in fields requiring precision — medicine, science, accounting, and editing.", traits: ["Analytical and detail-oriented", "Service-minded and helpful", "Health-conscious and practical", "Can be critical or overly perfectionist", "Excellent at organization and analysis"] },
  { index: 7, name: "Tula", english: "Libra", symbol: "♎", lord: "Shukra (Venus)", element: "Air (Vayu)", quality: "Movable (Chara)", description: "Tula, the scales, is ruled by Shukra (Venus) and represents balance, justice, and harmonious relationships. Tula natives are natural diplomats who seek fairness and beauty in all things. They excel in law, art, and partnerships. The challenge is decisiveness — the scales always weigh both sides.", traits: ["Diplomatic and fair-minded", "Charming and sociable", "Love of beauty and harmony", "Can be indecisive or overly people-pleasing", "Excellent in partnerships and negotiations"] },
  { index: 8, name: "Vrishchika", english: "Scorpio", symbol: "♏", lord: "Mangal (Mars)", element: "Water (Jala)", quality: "Fixed (Sthira)", description: "Vrishchika is ruled by Mangal (Mars) and represents intensity, transformation, and penetrating insight. The scorpion strikes precisely and powerfully. Vrishchika natives are deeply perceptive, passionate, and capable of profound transformation. They are drawn to mysteries, occult knowledge, and hidden truths.", traits: ["Intense and perceptive", "Deeply passionate and loyal", "Access to occult and hidden knowledge", "Capable of profound transformation", "Can be secretive, jealous, or vengeful"] },
  { index: 9, name: "Dhanu", english: "Sagittarius", symbol: "♐", lord: "Guru (Jupiter)", element: "Fire (Agni)", quality: "Dual (Dwiswabhava)", description: "Dhanu, the archer, is ruled by Guru (Jupiter) and represents wisdom, philosophy, and the aspiration for higher truth. The archer aims for distant horizons. Dhanu natives are optimistic, truth-seeking, and love travel, philosophy, and religious study. They are the teachers and explorers of the zodiac.", traits: ["Optimistic and philosophical", "Love of travel and exploration", "Truth-seeking and ethical", "Generous and enthusiastic", "Can be blunt, restless, or overconfident"] },
  { index: 10, name: "Makara", english: "Capricorn", symbol: "♑", lord: "Shani (Saturn)", element: "Earth (Prithvi)", quality: "Movable (Chara)", description: "Makara is ruled by Shani (Saturn) and represents discipline, ambition, and the mastery achieved through sustained effort. The sea-goat climbs steadily to the mountaintop. Makara natives are patient, responsible, and achieve great success through hard work and perseverance.", traits: ["Disciplined and ambitious", "Patient and persistent", "Responsible and dutiful", "Practical and career-oriented", "Can be overly serious or controlling"] },
  { index: 11, name: "Kumbha", english: "Aquarius", symbol: "♒", lord: "Shani (Saturn)", element: "Air (Vayu)", quality: "Fixed (Sthira)", description: "Kumbha, the water-bearer, is ruled by Shani (Saturn) and represents humanitarianism, innovation, and universal ideals. The water-bearer pours wisdom upon the world. Kumbha natives are visionary, independent, and committed to social progress. They see beyond the individual to the collective.", traits: ["Visionary and humanitarian", "Intellectually independent", "Innovative and unconventional", "Friendly yet detached", "Can be rebellious or emotionally aloof"] },
  { index: 12, name: "Meena", english: "Pisces", symbol: "♓", lord: "Guru (Jupiter)", element: "Water (Jala)", quality: "Dual (Dwiswabhava)", description: "Meena, the fish, is ruled by Guru (Jupiter) and represents compassion, imagination, and spiritual dissolution. The two fish swim in opposite directions — between the material and spiritual worlds. Meena natives are deeply empathetic, artistic, and spiritually gifted, but can lose themselves in illusion or escapism.", traits: ["Deeply compassionate and empathetic", "Artistic and imaginative", "Spiritually sensitive", "Intuitive and psychic", "Can be escapist, boundary-less, or easily influenced"] },
];

function RashiModal({ info, onClose }: { info: RashiInfo; onClose: () => void }) {
  const elementColors: Record<string, string> = {
    "Fire (Agni)": "bg-orange-50 border-orange-200 text-orange-700",
    "Earth (Prithvi)": "bg-green-50 border-green-200 text-green-700",
    "Air (Vayu)": "bg-sky-50 border-sky-200 text-sky-700",
    "Water (Jala)": "bg-blue-50 border-blue-200 text-blue-700",
  };
  const elClass = elementColors[info.element] ?? "bg-indigo-50 border-indigo-200 text-indigo-700";
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="panchang-gradient px-6 py-4 rounded-t-2xl">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="bg-white/20 text-white text-lg font-bold px-2 py-0.5 rounded-full">{info.symbol}</span>
                <span className="bg-white/20 text-white text-xs font-bold px-2 py-0.5 rounded-full">Rashi {info.index}</span>
              </div>
              <h2 className="text-2xl font-bold text-white">{info.name}</h2>
              <p className="text-indigo-200 text-sm mt-0.5">{info.english} · Ruled by {info.lord}</p>
            </div>
            <button onClick={onClose} className="text-white/80 hover:text-white text-2xl leading-none ml-4 mt-1">✕</button>
          </div>
        </div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-indigo-50 rounded-xl p-3 border border-indigo-100 text-center">
              <p className="text-xs text-indigo-600 font-semibold uppercase tracking-wide mb-1">Lord</p>
              <p className="text-sm font-bold text-stone-800">{info.lord.split(" ")[0]}</p>
            </div>
            <div className={`rounded-xl p-3 border text-center ${elClass}`}>
              <p className="text-xs font-semibold uppercase tracking-wide mb-1">Element</p>
              <p className="text-sm font-bold">{info.element.split(" ")[0]}</p>
            </div>
            <div className="bg-indigo-50 rounded-xl p-3 border border-indigo-100 text-center">
              <p className="text-xs text-indigo-600 font-semibold uppercase tracking-wide mb-1">Quality</p>
              <p className="text-sm font-bold text-stone-800">{info.quality.split(" ")[0]}</p>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-bold text-stone-700 mb-2 flex items-center gap-2">
              <span className="text-indigo-500">📖</span> About {info.name} ({info.english})
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">{info.description}</p>
          </div>
          <div>
            <h3 className="text-sm font-bold text-stone-700 mb-2 flex items-center gap-2">
              <span className="text-indigo-500">✨</span> Key Traits
            </h3>
            <ul className="space-y-1.5">
              {info.traits.map((t, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-stone-600">
                  <span className="text-orange-400 mt-0.5 flex-shrink-0">•</span>{t}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

type ActiveTab = "home" | "panchang" | "muhurat" | "festivals" | "planets" | "guide";

interface CalendarDay {
  date: Date;
  panchang: DayPanchang | null;
  isCurrentMonth: boolean;
  isToday: boolean;
  isSelected: boolean;
}

function Spinner() {
  return (
    <div className="flex items-center justify-center py-8 gap-3">
      <div className="w-8 h-8 rounded-full border-[3px] border-indigo-100 border-t-indigo-500 animate-spin" />
      <span className="text-indigo-600 text-sm font-medium">Computing Panchang…</span>
    </div>
  );
}

function SectionHeader({ icon, title, sub }: { icon: string; title: string; sub?: string }) {
  return (
    <div className="flex items-center gap-2 px-4 py-2 bg-indigo-50/70 border-b border-indigo-100">
      <span className="text-base">{icon}</span>
      <div>
        <p className="text-xs font-bold text-indigo-700 uppercase tracking-wide">{title}</p>
        {sub && <p className="text-xs text-indigo-400">{sub}</p>}
      </div>
    </div>
  );
}

function DetailRow({ icon, label, value, sub, highlight }: {
  icon: string; label: string; value: string; sub?: string; highlight?: boolean;
}) {
  return (
    <div className={`flex items-start gap-3 py-2.5 border-b border-slate-100 last:border-b-0 ${highlight ? "bg-amber-50/50" : ""}`}>
      <span className="text-base leading-none mt-0.5 flex-shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-indigo-600 uppercase tracking-wide">{label}</p>
        <p className="text-sm font-medium text-slate-800 mt-0.5">{value}</p>
        {sub && <p className="text-xs text-slate-400 mt-0.5">until {sub}</p>}
      </div>
    </div>
  );
}

// Grouped select for cities
function CitySelect({ value, onChange }: { value: City; onChange: (city: City) => void }) {
  const countryGroups = CITIES.reduce<Record<string, City[]>>((acc, city) => {
    if (!acc[city.country]) acc[city.country] = [];
    acc[city.country].push(city);
    return acc;
  }, {});

  return (
    <select
      value={value.name}
      onChange={e => {
        const city = CITIES.find(c => c.name === e.target.value);
        if (city) onChange(city);
      }}
      className="pl-3 pr-8 py-2 rounded-xl bg-white/15 border border-white/30 text-white text-sm font-medium
                 focus:outline-none focus:ring-2 focus:ring-white/40 appearance-none cursor-pointer
                 hover:bg-white/25 transition backdrop-blur-sm"
      style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='white' d='M6 8L1 3h10z'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "calc(100% - 10px) center" }}
    >
      {Object.entries(countryGroups).map(([country, cities]) => (
        <optgroup key={country} label={`— ${country} —`} style={{ color: "#333", background: "white" }}>
          {cities.map(city => (
            <option key={city.name} value={city.name} style={{ color: "#1e1b4b", background: "white" }}>
              {city.name}
            </option>
          ))}
        </optgroup>
      ))}
    </select>
  );
}

export default function PanchangPage() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [activeTab, setActiveTab] = useState<ActiveTab>("home");
  const [selectedCity, setSelectedCity] = useState<City>(CITIES[0]);
  const [selectedRashi, setSelectedRashi] = useState<RashiInfo | null>(null);
  const [viewDate, setViewDate] = useState<Date>(new Date(today));
  const [selectedDate, setSelectedDate] = useState<Date>(new Date(today));
  const [selectedPanchang, setSelectedPanchang] = useState<DayPanchang | null>(null);
  const [calendarDays, setCalendarDays] = useState<CalendarDay[]>([]);
  const [isLoadingMonth, setIsLoadingMonth] = useState(false);
  const [isLoadingSidebar, setIsLoadingSidebar] = useState(false);
  const [libraryLoaded, setLibraryLoaded] = useState(false);
  const panchangCacheRef = useRef<Map<string, DayPanchang>>(new Map());

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if ((window as any).Panchangam) { setLibraryLoaded(true); return; }
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/@ishubhamx/panchangam-js@2.2.6/dist/index.min.js";
    script.async = true;
    script.onload = () => setLibraryLoaded(true);
    script.onerror = () => setLibraryLoaded(true);
    document.head.appendChild(script);
  }, []);

  const getCacheKey = (date: Date, cityName: string) =>
    `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}-${cityName}`;

  const computeAndCache = useCallback(async (date: Date, city: City): Promise<DayPanchang> => {
    const key = getCacheKey(date, city.name);
    if (panchangCacheRef.current.has(key)) return panchangCacheRef.current.get(key)!;
    const result = await computeDayPanchang(date, city);
    panchangCacheRef.current.set(key, result);
    return result;
  }, []);

  const buildCalendar = useCallback(async (year: number, month: number, city: City, selDate: Date) => {
    setIsLoadingMonth(true);
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDay = new Date(firstDay);
    startDay.setDate(startDay.getDate() - startDay.getDay());
    const endDay = new Date(lastDay);
    endDay.setDate(endDay.getDate() + (6 - endDay.getDay()));

    const days: CalendarDay[] = [];
    const cur = new Date(startDay);
    while (cur <= endDay) {
      const d = new Date(cur);
      d.setHours(0, 0, 0, 0);
      days.push({
        date: d, panchang: null,
        isCurrentMonth: d.getMonth() === month,
        isToday: d.getTime() === today.getTime(),
        isSelected: d.getTime() === selDate.getTime(),
      });
      cur.setDate(cur.getDate() + 1);
    }
    setCalendarDays([...days]);

    const currentMonthDays = days.filter(d => d.isCurrentMonth);
    const batchSize = 5;
    for (let i = 0; i < currentMonthDays.length; i += batchSize) {
      const batch = currentMonthDays.slice(i, i + batchSize);
      await Promise.all(batch.map(async (day) => {
        try { day.panchang = await computeAndCache(day.date, city); } catch { /* skip */ }
      }));
      setCalendarDays(prev => [...prev]);
    }
    setIsLoadingMonth(false);
  }, [computeAndCache, today]);

  // Use selectedCity.name (string) for safe comparison in dependencies
  useEffect(() => {
    if (!libraryLoaded) return;
    panchangCacheRef.current.clear();
    buildCalendar(viewDate.getFullYear(), viewDate.getMonth(), selectedCity, selectedDate).catch(() => {
      setIsLoadingMonth(false);
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [libraryLoaded, viewDate.getFullYear(), viewDate.getMonth(), selectedCity.name]);

  useEffect(() => {
    if (!libraryLoaded) return;
    setIsLoadingSidebar(true);
    computeAndCache(selectedDate, selectedCity)
      .then(r => { setSelectedPanchang(r); setIsLoadingSidebar(false); })
      .catch(() => setIsLoadingSidebar(false));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [libraryLoaded, selectedDate.getTime(), selectedCity.name]);

  const handleCityChange = (city: City) => {
    panchangCacheRef.current.clear();
    setSelectedCity(city);
  };

  const handleDayClick = (day: CalendarDay) => {
    setSelectedDate(day.date);
    setCalendarDays(prev => prev.map(d => ({ ...d, isSelected: d.date.getTime() === day.date.getTime() })));
    if (!day.isCurrentMonth) setViewDate(new Date(day.date.getFullYear(), day.date.getMonth(), 1));
  };

  const goToToday = () => {
    const t = new Date(today);
    setSelectedDate(t); setViewDate(t);
    setCalendarDays(prev => prev.map(d => ({ ...d, isSelected: d.date.getTime() === t.getTime() })));
  };

  const selectedDateFormatted = new Intl.DateTimeFormat("en-IN", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  }).format(selectedDate);

  const selectedFestivals = getFestivalsForDate(selectedDate);
  const sp = selectedPanchang;

  const TABS: { id: ActiveTab; label: string; icon: string }[] = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "panchang", label: "Panchang", icon: "📿" },
    { id: "muhurat", label: "Muhurat", icon: "⏰" },
    { id: "festivals", label: "Festivals", icon: "🎉" },
    { id: "planets", label: "Planets", icon: "🪐" },
    { id: "guide", label: "Guide", icon: "📖" },
  ];

  // Sidebar: common across tabs
  const Sidebar = (
    <aside className="w-full lg:w-72 flex-shrink-0 space-y-4">
      <div className="bg-white rounded-2xl shadow-sm card-glow overflow-hidden border border-indigo-100">
        <div className="panchang-gradient px-4 py-3">
          <p className="text-indigo-200 text-xs font-semibold uppercase tracking-widest">Daily Panchang</p>
          <p className="text-white font-bold text-sm mt-0.5 leading-snug">{selectedDateFormatted}</p>
          <p className="text-indigo-300 text-xs mt-1">📍 {selectedCity.name}, {selectedCity.country}</p>
        </div>

        {selectedFestivals.length > 0 && (
          <div className="px-4 py-2.5 bg-rose-50 border-b border-rose-100">
            <p className="text-xs font-bold text-rose-600 uppercase tracking-widest mb-1.5">🎉 Today's Festivals</p>
            <div className="flex flex-wrap gap-1">
              {selectedFestivals.map((f, i) => (
                <span key={i} className="festival-badge text-white text-xs font-medium px-2 py-0.5 rounded-full shadow-sm">{f}</span>
              ))}
            </div>
          </div>
        )}

        {isLoadingSidebar ? <Spinner /> : sp ? (
          <>
            <SectionHeader icon="🌞" title="Astronomical Times" />
            <div className="px-4 py-1">
              <DetailRow icon="🌅" label="Sunrise" value={sp.sunrise} />
              <DetailRow icon="🌇" label="Sunset" value={sp.sunset} />
              <DetailRow icon="🌙" label="Moonrise" value={sp.moonrise} />
              <DetailRow icon="🌑" label="Moonset" value={sp.moonset} />
            </div>
            <SectionHeader icon="📿" title="Pancha Anga" sub="Five Elements" />
            <div className="px-4 py-1">
              <DetailRow icon="🌓" label="Tithi" value={sp.tithi} sub={sp.tithiEnd} />
              <DetailRow icon="⭐" label="Nakshatra" value={sp.nakshatra} sub={sp.nakshatraEnd} />
              <DetailRow icon="🔯" label="Yoga" value={sp.yoga} />
              <DetailRow icon="☯️" label="Karana" value={sp.karana} />
              <DetailRow icon="🌊" label="Paksha" value={sp.paksha} />
              <DetailRow icon="📅" label="Vara" value={sp.weekdayName} />
            </div>
            <SectionHeader icon="📜" title="Vedic Calendar" />
            <div className="px-4 py-1">
              <DetailRow icon="🗓️" label="Vikram Samvat" value={String(sp.vikramSamvat)} />
              <DetailRow icon="📆" label="Shaka Samvat" value={String(sp.shakaSamvat)} />
              <DetailRow icon="🌤️" label="Ayana" value={sp.ayana} />
              <DetailRow icon="🍃" label="Ritu" value={sp.ritu} />
              <DetailRow icon="☀️" label="Sun Sign" value={sp.sunsign} />
              <DetailRow icon="🌙" label="Moon Sign" value={sp.moonsign} />
            </div>
          </>
        ) : (
          <p className="text-sm text-slate-400 py-6 text-center">Select a date</p>
        )}
      </div>

      {sp && <VedicClock city={selectedCity} sunriseStr={sp.sunrise} sunsetStr={sp.sunset} />}
    </aside>
  );

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg, #f0f0ff 0%, #e8e8f8 50%, #f5f0ff 100%)" }}>
      {/* Header */}
      <header className="panchang-gradient shadow-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/15 rounded-full flex items-center justify-center text-xl border border-white/20">
                🕉️
              </div>
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight">Om Panchang</h1>
                <p className="text-indigo-200 text-xs">Hindu Calendar & Vedic Almanac</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-white/70 text-sm hidden sm:block">📍</span>
              <CitySelect value={selectedCity} onChange={handleCityChange} />
            </div>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex overflow-x-auto scrollbar-hide">
              {TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition
                    ${activeTab === tab.id
                      ? "border-amber-400 text-amber-300 bg-white/10"
                      : "border-transparent text-indigo-200 hover:text-white hover:bg-white/5"
                    }`}
                >
                  <span className="text-sm">{tab.icon}</span>
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* ===== HOME TAB ===== */}
      {activeTab === "home" && (
        <main className="max-w-7xl mx-auto px-4 py-5 flex flex-col lg:flex-row gap-5">
          {Sidebar}
          <div className="flex-1 space-y-4">
            {/* Calendar */}
            <div className="bg-white rounded-2xl shadow-sm card-glow overflow-hidden border border-indigo-100">
              <div className="flex items-center justify-between px-5 py-3.5 border-b border-indigo-100">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => { const d = new Date(viewDate); d.setMonth(d.getMonth() - 1); setViewDate(d); }}
                    className="w-8 h-8 rounded-full border border-indigo-200 text-indigo-500 hover:bg-indigo-50 flex items-center justify-center text-lg font-bold transition"
                  >‹</button>
                  <h2 className="text-lg font-bold text-slate-800 min-w-[180px] text-center">
                    {MONTHS[viewDate.getMonth()]} {viewDate.getFullYear()}
                  </h2>
                  <button
                    onClick={() => { const d = new Date(viewDate); d.setMonth(d.getMonth() + 1); setViewDate(d); }}
                    className="w-8 h-8 rounded-full border border-indigo-200 text-indigo-500 hover:bg-indigo-50 flex items-center justify-center text-lg font-bold transition"
                  >›</button>
                </div>
                <button onClick={goToToday} className="px-4 py-1.5 panchang-gradient text-white text-xs font-bold rounded-full shadow-sm hover:opacity-90 transition">
                  Today
                </button>
              </div>
              <div className="grid grid-cols-7 border-b border-indigo-50">
                {WEEKDAYS.map((day, i) => (
                  <div key={day} className={`py-2 text-center text-xs font-bold uppercase tracking-wider ${i === 0 ? "text-rose-500" : i === 6 ? "text-indigo-400" : "text-slate-400"}`}>
                    {day}
                  </div>
                ))}
              </div>
              {isLoadingMonth && calendarDays.length === 0 && <div className="py-10"><Spinner /></div>}
              <div className="grid grid-cols-7">
                {calendarDays.map((day, idx) => {
                  const festivals = getFestivalsForDate(day.date);
                  const isSun = day.date.getDay() === 0;
                  const isSat = day.date.getDay() === 6;
                  return (
                    <div key={idx} onClick={() => handleDayClick(day)}
                      className={`relative border-b border-r border-indigo-50 cursor-pointer min-h-[78px] p-1.5 day-card-hover
                        ${!day.isCurrentMonth ? "opacity-40 bg-slate-50/30" : ""}
                        ${day.isSelected ? "bg-indigo-600 text-white ring-2 ring-indigo-400 ring-inset z-10" : "hover:bg-indigo-50/60"}
                        ${day.isToday && !day.isSelected ? "bg-amber-50 ring-2 ring-amber-400 ring-inset" : ""}
                      `}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-bold
                          ${day.isSelected ? "bg-white text-indigo-700" : ""}
                          ${day.isToday && !day.isSelected ? "bg-amber-400 text-white" : ""}
                          ${!day.isSelected && !day.isToday ? (isSun ? "text-rose-500" : isSat ? "text-indigo-400" : "text-slate-700") : ""}
                        `}>{day.date.getDate()}</span>
                        {festivals.length > 0 && <span className={`w-1.5 h-1.5 rounded-full ${day.isSelected ? "bg-amber-300" : "bg-rose-500"}`} />}
                      </div>
                      {day.isCurrentMonth && (
                        <div className="space-y-0.5">
                          {day.panchang ? (
                            <>
                              <p className={`text-xs font-medium leading-tight truncate ${day.isSelected ? "text-indigo-100" : "text-indigo-700"}`}>{day.panchang.tithi}</p>
                              <p className={`text-xs leading-tight truncate hidden sm:block ${day.isSelected ? "text-indigo-200" : "text-slate-400"}`}>{day.panchang.nakshatra}</p>
                            </>
                          ) : (
                            <div className={`h-2.5 rounded animate-pulse ${day.isSelected ? "bg-indigo-400" : "bg-indigo-100"}`} />
                          )}
                          {festivals.length > 0 && (
                            <p className={`text-xs font-semibold leading-tight truncate ${day.isSelected ? "text-amber-300" : "text-rose-600"}`}>🎉 {festivals[0]}</p>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="px-4 py-2.5 border-t border-indigo-50 bg-indigo-50/30 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-amber-400" /><span>Today</span></div>
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-indigo-600" /><span>Selected</span></div>
                <div className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-rose-500" /><span>Festival</span></div>
                <div className="ml-auto text-indigo-500 font-medium">🕉️ Based on {selectedCity.name}</div>
              </div>
            </div>
            {/* Planets + Festivals preview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <PlanetaryPositions date={selectedDate} />
              <UpcomingFestivals today={today} />
            </div>
          </div>
        </main>
      )}

      {/* ===== PANCHANG TAB ===== */}
      {activeTab === "panchang" && (
        <main className="max-w-7xl mx-auto px-4 py-5 flex flex-col lg:flex-row gap-5">
          {Sidebar}
          <div className="flex-1">
            <div className="bg-white rounded-2xl shadow-sm card-glow overflow-hidden border border-indigo-100">
              <div className="panchang-gradient px-5 py-4">
                <p className="text-indigo-200 text-xs uppercase tracking-widest font-semibold">Full Panchang Details</p>
                <p className="text-white font-bold text-lg mt-0.5">{selectedDateFormatted}</p>
                <p className="text-indigo-200 text-sm">📍 {selectedCity.name}, {selectedCity.country}</p>
              </div>
              {isLoadingSidebar ? <Spinner /> : sp ? (
                <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    { icon: "🌅", label: "Sunrise", value: sp.sunrise },
                    { icon: "🌇", label: "Sunset", value: sp.sunset },
                    { icon: "🌙", label: "Moonrise", value: sp.moonrise },
                    { icon: "🌑", label: "Moonset", value: sp.moonset },
                    { icon: "🌓", label: "Tithi", value: sp.tithi, sub: sp.tithiEnd ? `Ends: ${sp.tithiEnd}` : undefined },
                    { icon: "⭐", label: "Nakshatra", value: sp.nakshatra, sub: sp.nakshatraEnd ? `Ends: ${sp.nakshatraEnd}` : undefined },
                    { icon: "🔯", label: "Yoga", value: sp.yoga },
                    { icon: "☯️", label: "Karana", value: sp.karana },
                    { icon: "🌊", label: "Paksha", value: sp.paksha },
                    { icon: "📅", label: "Vara (Sanskrit)", value: sp.weekdayName },
                    { icon: "🗓️", label: "Vikram Samvat", value: String(sp.vikramSamvat) },
                    { icon: "📆", label: "Shaka Samvat", value: String(sp.shakaSamvat) },
                    { icon: "🌤️", label: "Ayana", value: sp.ayana },
                    { icon: "🍃", label: "Ritu (Season)", value: sp.ritu },
                    { icon: "☀️", label: "Sun Sign (Rashi)", value: sp.sunsign },
                    { icon: "🌙", label: "Moon Sign (Rashi)", value: sp.moonsign },
                  ].map(item => (
                    <div key={item.label} className="flex items-start gap-3 p-3 rounded-xl bg-indigo-50/50 border border-indigo-100">
                      <span className="text-xl">{item.icon}</span>
                      <div>
                        <p className="text-xs font-bold text-indigo-600 uppercase tracking-wide">{item.label}</p>
                        <p className="text-sm font-semibold text-slate-800 mt-0.5">{item.value}</p>
                        {item.sub && <p className="text-xs text-slate-400 mt-0.5">{item.sub}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : <p className="text-slate-400 text-sm text-center py-10">Loading panchang data…</p>}
            </div>
          </div>
        </main>
      )}

      {/* ===== MUHURAT TAB ===== */}
      {activeTab === "muhurat" && (
        <main className="max-w-7xl mx-auto px-4 py-5 flex flex-col lg:flex-row gap-5">
          {Sidebar}
          <div className="flex-1 space-y-4">
            <div className="bg-white rounded-2xl shadow-sm card-glow overflow-hidden border border-indigo-100">
              <div className="panchang-gradient px-5 py-4">
                <p className="text-indigo-200 text-xs uppercase tracking-widest font-semibold">Muhurta Timings</p>
                <p className="text-white font-bold text-lg mt-0.5">{selectedDateFormatted}</p>
              </div>
              {isLoadingSidebar ? <Spinner /> : sp ? (
                <div className="p-5 space-y-3">
                  {/* Auspicious */}
                  <div>
                    <p className="text-xs font-bold text-emerald-600 uppercase tracking-widest mb-2">✨ Auspicious Times</p>
                    <div className="rounded-xl overflow-hidden border border-emerald-100">
                      {[
                        { icon: "✨", label: "Abhijit Muhurta", value: sp.abhijitMuhurta, desc: "The most auspicious time of the day — excellent for all new beginnings" },
                        { icon: "🌅", label: "Brahma Muhurta", value: "~96 min before sunrise", desc: "The creator's time — ideal for prayer, meditation and study" },
                      ].map((item, i) => (
                        <div key={item.label} className={`flex items-start gap-4 p-4 ${i > 0 ? "border-t border-emerald-50" : ""} bg-emerald-50/40`}>
                          <span className="text-2xl">{item.icon}</span>
                          <div className="flex-1">
                            <p className="font-bold text-slate-800 text-sm">{item.label}</p>
                            <p className="text-indigo-700 font-semibold text-sm mt-0.5">{item.value}</p>
                            <p className="text-xs text-slate-500 mt-1">{item.desc}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  {/* Inauspicious */}
                  <div>
                    <p className="text-xs font-bold text-rose-600 uppercase tracking-widest mb-2">⚠️ Inauspicious Times (Avoid for New Work)</p>
                    <div className="rounded-xl overflow-hidden border border-rose-100">
                      {[
                        { icon: "⚠️", label: "Rahu Kalam", value: sp.rahuKalam, desc: "Period ruled by Rahu — avoid starting new ventures" },
                        { icon: "☠️", label: "Yamaganda Kalam", value: sp.yamagandaKalam, desc: "Inauspicious period ruled by the Lord of Death" },
                        { icon: "🌀", label: "Gulika Kalam", value: sp.gulikaKalam, desc: "Period ruled by Gulika (Mandi) — unfavorable for new beginnings" },
                      ].map((item, i) => (
                        <div key={item.label} className={`flex items-start gap-4 p-4 ${i > 0 ? "border-t border-rose-50" : ""} bg-rose-50/30`}>
                          <span className="text-2xl">{item.icon}</span>
                          <div className="flex-1">
                            <p className="font-bold text-slate-800 text-sm">{item.label}</p>
                            <p className="text-rose-700 font-semibold text-sm mt-0.5">{item.value}</p>
                            <p className="text-xs text-slate-500 mt-1">{item.desc}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
                    <p className="font-bold mb-1">📌 Note</p>
                    <p className="text-xs leading-relaxed">All timings are calculated based on the local sunrise and sunset for {selectedCity.name}. Drik (observed) method is used for computation.</p>
                  </div>
                </div>
              ) : <p className="text-slate-400 text-sm text-center py-10">Select a date to view muhurtas</p>}
            </div>
          </div>
        </main>
      )}

      {/* ===== FESTIVALS TAB ===== */}
      {activeTab === "festivals" && (
        <main className="max-w-7xl mx-auto px-4 py-5 flex flex-col lg:flex-row gap-5">
          {Sidebar}
          <div className="flex-1">
            <UpcomingFestivals today={today} />
          </div>
        </main>
      )}

      {/* ===== PLANETS TAB ===== */}
      {activeTab === "planets" && (
        <main className="max-w-7xl mx-auto px-4 py-5 flex flex-col lg:flex-row gap-5">
          {Sidebar}
          <div className="flex-1 space-y-4">
            <PlanetaryPositions date={selectedDate} />
            <div className="bg-white rounded-2xl shadow-sm card-glow border border-indigo-100 p-5">
              <p className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-3">🔭 About Vedic Astronomy</p>
              <p className="text-sm text-slate-600 leading-relaxed">
                In Vedic Jyotish (astrology), planetary positions are calculated in the <strong>Sidereal (Nirayana) zodiac</strong> 
                using the Lahiri Ayanamsa to correct for the precession of equinoxes. The nine grahas 
                (Navagrahas) — Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, and Ketu — 
                are considered the key influencing celestial bodies. Their positions in the 12 rashis 
                (zodiac signs) determine auspicious periods, dashas, and life events in Vedic astrology.
              </p>
              <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {RASHI_DATA.map((rashi) => (
                  <button
                    key={rashi.index}
                    onClick={() => setSelectedRashi(rashi)}
                    className="group flex items-center gap-2 bg-indigo-50 hover:bg-indigo-100 hover:border-orange-300 border border-transparent rounded-lg px-2 py-1.5 text-indigo-700 font-medium transition text-left"
                  >
                    <span className="text-base group-hover:scale-110 transition-transform">{rashi.symbol}</span>
                    <span>{rashi.index}. {rashi.name} ({rashi.english})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </main>
      )}

      {/* ===== GUIDE TAB ===== */}
      {activeTab === "guide" && (
        <main className="max-w-7xl mx-auto px-4 py-5">
          <ReferenceSection />
        </main>
      )}

      {/* Footer */}
      <footer className="text-center py-6 text-slate-400 text-xs border-t border-indigo-100 bg-white/60 mt-4">
        <p className="flex items-center justify-center gap-2 font-medium text-slate-500">
          <span>🕉️</span>
          <span>Om Panchang · Hindu Calendar & Vedic Almanac</span>
          <span>🕉️</span>
        </p>
        <p className="mt-1">Astronomical calculations · Location-aware</p>
      </footer>

      {/* Rashi Modal */}
      {selectedRashi && (
        <RashiModal info={selectedRashi} onClose={() => setSelectedRashi(null)} />
      )}
    </div>
  );
}
